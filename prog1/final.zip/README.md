

If using mac: Please unzip using mac terminal (the default mac unzipper will automatically add a root directory when unzipping)